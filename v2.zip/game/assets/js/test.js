$(document).ready(function(){

  // event listeners
  $("#remaining-time").hide();
  $("#countdown").hide();
  $("#start").on('click', trivia.countDown); // click the start button in index.html to start the game
  $(document).on('click' , '.option', trivia.guessChecker); // click the option button to check answer

})

var trivia = {
  // trivia properties
  correct: 0,
  incorrect: 0,
  unanswered: 0,
  currentSet: 0,
  timer: 15,
  timerOn: false,
  timerId: '',

  // count down
  count_down_timer: 3,
  countDownID: '',

  // questions options and answers data
  // q1-q4 questions, answer and explanation are from
  // https://www.cnbc.com/2017/09/19/94-percent-of-americans-failed-this-financial-literacy-quiz.html

  // q
  questions: {
    q1: 'How much will the typical married couple retiring at age 65 spend on out-of-pocket costs for health care throughout retirement (in today’s dollars)',
    q2: 'If you purchase a bond and interest rates rise, what will happen to the price of the bond?',
    q3: 'A typical 65-year-old man can expect to live, on average, for how many more years?',
    q4: 'What is the average annual rate of inflation for college tuition around the country?',
    q5: 'How many months of living costs should you have in your savings?',
    q6: 'Income does NOT impact your credit score, true or false?',
    q7: 'What is true about credit cards?',
    q8: 'Select the answer that is NOT part of your credit report',
    q9: 'The lower your credit score the lower the risk is to lenders',
    q10: 'What is considered a good FICO credit score?',
    q11: 'The most basic Wealth Protection Plan that I should have is',
    q12: 'I have to set aside an amount of monthly savings equal to'
  },
  options: {
    q1: ['$50,000', '$100,000', '$200,000', '$250,000'],
    q2: ['Rise', 'Stay the same', 'Fall'],
    q3: ['About 10 more years', 'About 15 more years', 'About 20 more years', 'About 25 more years'],
    q4: ['2 percent', '5 percent', '8 percent', '11 percent'],
    q5: ['1 month', '4-6 months', '10-12 months'],
    q6: ['TRUE', 'False'],
    q7: ['allows you to borrow money to buy things', 'A loan that has to be paid off every month', 'If you do not pay in full before your due date, you may incur interest', 'All of the above'],
    q8: ['Payment History','Length of credit history', 'Your race', 'Credit utilization'],
    q9: ['TRUE', 'FALSE'],
    q10: ['mid to high 500\'s', 'mid to high 600\'s', 'mid to high 700\'s'],
    q11: ['Life Insurance','Disability Insurance','Health Insurance','Retirement Insurance'],
    q12: ['10% - 15% of my monthly income','20% - 30% of my yearly income','The balance after paying off my bills etc','A percentage based on how many dependants I have']



  },
  answers: {
    q1: '$250,000',
    q2: 'Fall',
    q3: 'About 20 more years',
    q4: '8 percent',
    q5: '4-6 months',
    q6: 'TRUE',
    q7: 'All of the above',
    q8: 'Your race',
    q9: 'FALSE',
    q10: 'mid to high 700\'s',
    q11: 'Health Insurance',
    q12: '10% - 15% of my monthly income'
  },
  // trivia methods
  // to implement the coutdown screen
  countDown: function(){
    $('#countdown').show();

    // $('#countdown-timer').text(trivia.count_down_timer);
    $('#countdown-time').text(trivia.count_down_timer);

    trivia.countDownID = setInterval(trivia.countDownTimerRunning, 1000);
    // console.log("still running");

  },

  countDownTimerRunning: function(){
    // console.log("from countDownTimerRunning" + trivia.count_down_timer);
    if(trivia.count_down_timer > 0){
      // $('#countdown-timer').text(trivia.count_down_timer);
      $('#countdown-time').text(trivia.count_down_timer);
      trivia.count_down_timer--;
    }
    else {
      trivia.startGame();
    }
  },


  // method to initialize game
  startGame: function(){
    // restarting game results
    trivia.currentSet = 0;
    trivia.correct = 0;
    trivia.incorrect = 0;
    trivia.unanswered = 0;
    clearInterval(trivia.timerId);
    // clear cout down
    clearInterval(trivia.countDownID)
    // hide the coutdown
    $('#countdown').hide();

    // show game section
    $('#game').show();

    //  empty last results
    $('#results').html('');

    // show timer
    $('#timer').text(trivia.timer);

    // remove start button
    $('#start').hide();

    $('#remaining-time').show();

    // ask first question
    trivia.nextQuestion();

  },
  // method to loop through and display questions and options
  nextQuestion : function(){

    // set timer to 15 seconds each question
    trivia.timer = 15;
    $('#timer').removeClass('last-seconds');
    $('#timer').text(trivia.timer);

    // to prevent timer speed up
    if(!trivia.timerOn){
      trivia.timerId = setInterval(trivia.timerRunning, 1000);
    }

    // gets all the questions then indexes the current questions
    var questionContent = Object.values(trivia.questions)[trivia.currentSet];
    $('#question').text(questionContent);

    // an array of all the user options for the current question
    var questionOptions = Object.values(trivia.options)[trivia.currentSet];

    // creates all the trivia guess options in the html
    $.each(questionOptions, function(index, key){
      $('#options').append($('<button class="option btn btn-info btn-lg">'+key+'</button>'));
    })

  },
  // method to decrement counter and count unanswered if timer runs out
  timerRunning : function(){
    // if timer still has time left and there are still questions left to ask
    if(trivia.timer > -1 && trivia.currentSet < Object.keys(trivia.questions).length){
      $('#timer').text(trivia.timer);
      trivia.timer--;
        if(trivia.timer === 4){
          $('#timer').addClass('last-seconds');
        }
    }
    // the time has run out and increment unanswered, run result
    else if(trivia.timer === -1){
      trivia.unanswered++;
      trivia.result = false;
      clearInterval(trivia.timerId);
      resultId = setTimeout(trivia.guessResult, 1000);
      $('#results').html('<h3>Out of time! The answer was '+ Object.values(trivia.answers)[trivia.currentSet] +'</h3>');
    }
    // if all the questions have been shown end the game, show results
    else if(trivia.currentSet === Object.keys(trivia.questions).length){

      // adds results of game (correct, incorrect, unanswered) to the page
      $('#results').html('<h3>Thank you for playing!</h3>'+
        '<p>Correct: '+ trivia.correct +'</p>'+
        '<p>Incorrect: '+ trivia.incorrect +'</p>'+
        '<p>Unaswered: '+ trivia.unanswered +'</p>'+
        '<p>Please play again!</p>');

      // hide game sction
      $('#game').hide();

      // show start button to begin a new game
      $('#start').show();
    }

  },
  // method to evaluate the option clicked
  guessChecker : function() {

    // timer ID for gameResult setTimeout
    var resultId;

    // the answer to the current question being asked
    var currentAnswer = Object.values(trivia.answers)[trivia.currentSet];

    // if the text of the option picked matches the answer of the current question, increment correct
    if($(this).text() === currentAnswer){
      // turn button green for correct
      $(this).addClass('btn-success').removeClass('btn-info');

      trivia.correct++;
      clearInterval(trivia.timerId);
      resultId = setTimeout(trivia.guessResult, 2000);
      $('#results').html('<h3>Correct Answer!</h3>');
    }
    // else the user picked the wrong option, increment incorrect
    else{
      // turn button clicked red for incorrect
      $(this).addClass('btn-danger').removeClass('btn-info');

      trivia.incorrect++;
      clearInterval(trivia.timerId);
      // resultId = setTimeout(trivia.guessResult, 2000);
      // $('#results').html('<h3>Better luck next time! '+ '\nThe correct answer is '+ currentAnswer +'</h3>');

      // use this to show the explanation
      if (trivia.currentSet == 0) {
        // resultId = setTimeout(trivia.guessResult, 2000);
        resultId = setTimeout(trivia.guessResult, 8000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +
        '<br/><br/> According to the survey, the average 65-year-old couple covered by Medicare parts B, D and a supplemental insurance policy will spend more than $250,000 on health-care costs in retirement.</h3> ');
      }
      else if (trivia.currentSet == 1) {
        // resultId = setTimeout(trivia.guessResult, 2000);
        resultId = setTimeout(trivia.guessResult, 8000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +
        '<br/><br/> Bond prices and interest rates have an inverse relationship, so when interest rates rise, bond prices drop and vice versa. </h3>');
      }
      else if (trivia.currentSet == 2) {
        // resultId = setTimeout(trivia.guessResult, 2000);
        resultId = setTimeout(trivia.guessResult, 8000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +
        '<br/><br/> According to data from the Social Security Administration, men can expect to live to around 84 years old. That should be reflected in their retirement plan so they don’t outlive their savings. Women can expect to live longer, to around 87 years old. </h3>');
      }
      else if (trivia.currentSet == 3) {
        // resultId = setTimeout(trivia.guessResult, 2000);
        resultId = setTimeout(trivia.guessResult, 8000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +
        '<br/><br/> “At 8 percent annual inflation, college tuition doubles about every nine years,” Financial Engines explains. </h3>');
      }
      else if (trivia.currentSet == 6) {
        // resultId = setTimeout(trivia.guessResult, 2000);
        resultId = setTimeout(trivia.guessResult, 8000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +
        '<br/><br/> Credit card is a type of loan that has pros and cons. Learn more here. https://www.nerdwallet.com/blog/nerdscholar/credit-card. </h3>');
      }
      else if (trivia.currentSet == 7) {
        // resultId = setTimeout(trivia.guessResult, 2000);
        resultId = setTimeout(trivia.guessResult, 8000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +
        '<br/><br/> It is iligal to use race, religion, national origin, sex and marital status to calculate a credit score.</h3>');
      }
      else if (trivia.currentSet == 9) {
        // resultId = setTimeout(trivia.guessResult, 2000);
        resultId = setTimeout(trivia.guessResult, 8000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +
        '<br/><br/> Credit scores usually range from 300 to 850, and anything above high 700\'s is considered good.</h3>. ');
      }
      else {
        resultId = setTimeout(trivia.guessResult, 2000);
        $('#results').html('<h3>Better luck next time! </h3>' + '<h3>The correct answer is '+ currentAnswer +'</h3>');
      }
    }

  },
  // method to remove previous question results and options
  guessResult : function(){

    // increment to next question set
    trivia.currentSet++;

    // remove the options and results
    $('.option').remove();
    $('#results h3').remove();

    // begin next question
    trivia.nextQuestion();

  }

}
